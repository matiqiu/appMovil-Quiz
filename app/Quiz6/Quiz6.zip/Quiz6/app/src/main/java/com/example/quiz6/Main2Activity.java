package com.example.quiz6;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import java.util.Locale;

public class Main2Activity extends AppCompatActivity {

    private MediaPlayer sonido1;

    Button btn_exit;
    Button btn_help;
    Button btn_credits;
    ImageButton btn_pause;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        btn_exit = (Button) findViewById(R.id.btn_exit);
        btn_credits = (Button) findViewById(R.id.btn_credits);
        btn_pause = (ImageButton) findViewById(R.id.btn_pause);

        ////////////
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        ////////////

        sonido1=MediaPlayer.create(this,R.raw.season_joy);
        sonido1.setLooping(true);
        sonido1.start();

        btn_exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_HOME);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);

            }
        });

        findViewById(R.id.btn_help).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mostrarAyuda();
            }
        });
        findViewById(R.id.btn_credits).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mostrarCreditos();
            }
        });

        btn_pause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (sonido1.isPlaying()){
                    sonido1.pause();
                    Toast.makeText(getApplicationContext(),"Sonido desactivado",Toast.LENGTH_SHORT).show();
                }
                else
                {
                    sonido1.start();
                    Toast.makeText(getApplicationContext(),"Sonido activado",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (sonido1.isPlaying()){
            sonido1.stop();
            sonido1.release();
        }
    }
    @Override
    protected void onResume() {
        super.onResume();
        sonido1.start();
    }
    @Override
    protected void onPause() {
        super.onPause();
        sonido1.pause();
    }

    public void Jugar(View view){
        Intent jugar = new Intent(this, MainActivity.class);
        startActivity(jugar);
    }

    public void mostrarAyuda(){

        /*String mensaje = String.format(Locale.getDefault(),
                "Cada pregunta consta de 4 opciones, la cual es una la correcta o en defecto dos," +
                        "por cada respuesta correcta se suman 10 puntos, por cada incorrecta se restan 10 puintos " +
                        "y por las preguntas no contestadas se restara 5 puntos");
*/
        AlertDialog.Builder builder = new AlertDialog.Builder(Main2Activity.this);
        builder.setTitle("Ayuda");
        builder.setMessage("Cada pregunta consta de 4 opciones, la cual es una la correcta o en defecto dos," +
                "por cada respuesta correcta se suman 10 puntos, por cada incorrecta se restan 10 puintos" +
                "y por las preguntas no contestadas se restara 5 puntos")
                .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                })
                .setCancelable(false)
                .show();
    }

    public void mostrarCreditos(){

        AlertDialog.Builder builder = new AlertDialog.Builder(Main2Activity.this);
        builder.setTitle("Desarrolladores");
        builder.setMessage("- Freddy Mercury \n- El_bola \n- matiqiu")
                .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                })
                .setCancelable(false)
                .show();
    }
}
