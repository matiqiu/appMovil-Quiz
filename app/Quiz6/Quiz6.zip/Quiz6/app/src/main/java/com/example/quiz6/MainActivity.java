package com.example.quiz6;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.PersistableBundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.QuickContactBadge;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    public static final String CORRECT_ANSWER = "correct_answer";
    public static final String PREGUNTA_ACTUAL = "pregunta_actual";
    public static final String RESPUESTA_ES_CORRECTA = "respuesta_es_correcta";
    public static final String RESPUESTA = "respuesta";
    private int ids_answers[] = {
            R.id.answer1, R.id.answer2, R.id.answer3, R.id.answer4
    };
    private String[] preguntas_todas;
    private TextView text_question;
    private RadioGroup group;
    private Button btn_next, btn_prev;
    private TextView txt_tiempo;

    private int correct_answer;
    private int pregunta_actual;
    private boolean[] respuesta_es_correcta;
    private int[] respuesta;

    private MediaPlayer sonido1;
    private MediaPlayer sonido2;
    private MediaPlayer sonido3;

    public int puntaje_;

    TextView txt_score;
    //private int mScore = 0;


    @Override
    public void onSaveInstanceState(Bundle outState) {
        Log.i("lifecycle", "onSaveInstanceState");
        super.onSaveInstanceState(outState);

        outState.putInt(CORRECT_ANSWER,correct_answer);
        outState.putInt(PREGUNTA_ACTUAL,pregunta_actual);
        outState.putBooleanArray(RESPUESTA_ES_CORRECTA, respuesta_es_correcta);
        outState.putIntArray(RESPUESTA, respuesta);
    }

    public void Retirarse(View view){
        Intent retirarse = new Intent(this, Main2Activity.class);
        startActivity(retirarse);
    }

    @Override
    protected void onStop() {
        Log.i("lifecycle", "onStop");
        super.onStop();
    }

    @Override
    protected void onStart() {
        Log.i("lifecycle", "onStart");
        super.onStart();
    }

    @Override
    protected void onDestroy() {
        Log.i("lifecycle", "onDestroy");
        super.onDestroy();
        if (sonido1.isPlaying()){
            sonido1.stop();
            sonido1.release();

        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        sonido1.start();
    }
    @Override
    protected void onPause() {
        super.onPause();
        sonido1.pause();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        Log.i("lifecycle", "onCreate");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ////////////
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        ////////////

        ////////
        txt_score = (TextView) findViewById(R.id.txt_score);
        //txt_score.setText("Score: "+ mScore);
        ///////

        text_question = (TextView) findViewById(R.id.text_question);
        group = (RadioGroup) findViewById(R.id.answer_group);
        btn_next = (Button) findViewById(R.id.btn_check);
        btn_prev = (Button) findViewById(R.id.btn_prev);

        txt_tiempo = (TextView) findViewById(R.id.txt_tiempo);

        preguntas_todas = getResources().getStringArray(R.array.preguntas_todas);
        startOver();

        sonido1=MediaPlayer.create(this,R.raw.first_light);
        sonido2=MediaPlayer.create(this,R.raw.correct_ding);
        sonido3=MediaPlayer.create(this,R.raw.incorrecto);
        sonido1.setLooping(true);
        sonido1.start();


        //TODO: Usar solo en caso de dejar boton "Atras"

        if (savedInstanceState == null){
            startOver();
        }
        else{
            Bundle state = savedInstanceState;
            correct_answer = state.getInt(CORRECT_ANSWER);
            pregunta_actual = state.getInt(PREGUNTA_ACTUAL);
            respuesta_es_correcta = state.getBooleanArray(RESPUESTA_ES_CORRECTA);
            respuesta = state.getIntArray(RESPUESTA);
            showquestion();
        }

        // TODO: Cuando clican el boton deberia pasar a lasiguiente pregunta



        btn_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer();


                /*
                if (respuesta == correct_answer)
                {
                    Toast.makeText(MainActivity.this, "Muy bien", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(MainActivity.this, "Incorrecto", Toast.LENGTH_SHORT).show();
                }*/

                if(pregunta_actual < preguntas_todas.length-1)
                {

                    int puntaje = 50;

                    for (int i =0; i < preguntas_todas.length; i++){
                        if (respuesta_es_correcta[i]){
                            puntaje = puntaje +5;

                        }
                        else if (respuesta[i] == -1){

                            puntaje = puntaje - 5;
                        }
                        else
                        {
                            puntaje= puntaje - 15;
                        }
                    }
                    puntaje_ = puntaje;
                    txt_score.setText(""+ puntaje);

                    //TODO: Desbloquear para usar preguntas random

                    /*
                    Random rand = new Random();
                    int pregunta = rand.nextInt(3);

                    text_question.setText(preguntas_todas[pregunta]);
                    */

                    pregunta_actual++;
                    showquestion();
                }
                else {
                    checkResults();
                }

                /*
                for (int i= 0; i < respuesta_es_correcta.length; i++) {
                    Log.i("pauek", String.format("Respuesta %d: %b",i,respuesta_es_correcta));
                }

                 */
            }
        });

        btn_prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer();
                if (pregunta_actual > 0){
                    pregunta_actual--;
                    showquestion();
                }
            }
        });
    }

    private void startOver() {
        respuesta_es_correcta = new boolean[preguntas_todas.length];
        respuesta = new int[preguntas_todas.length];
        for (int i = 0; i < respuesta.length; i++)
        {
            respuesta[i] = -1;
        }
        pregunta_actual = 0;
        showquestion();
    }

    private void checkAnswer() {

        int id = group.getCheckedRadioButtonId();
        int ans = -1;
        for(int i=0; i < ids_answers.length; i++)
        {
            if (ids_answers[i] == id)
            {
                ans = i;
            }
        }
        if(ans == correct_answer)
        {
            Toast.makeText(getApplicationContext(),"Correcto",Toast.LENGTH_SHORT).show();

            sonido2.start();
        }
        else
        {
            Toast.makeText(getApplicationContext(),"Incorrecto",Toast.LENGTH_SHORT).show();

            sonido3.start();
        }
        respuesta_es_correcta[pregunta_actual] = (ans == correct_answer);
        respuesta[pregunta_actual] = ans;
    }

    private void checkResults() {
        int correctas = 0, incorrectas = 0, nocontestadas = 0, puntajeM = 0;

        for (int i =0; i < preguntas_todas.length; i++){
            if (respuesta_es_correcta[i]){
                correctas++;


                ///////////////
                //mScore++;
                //txt_score.setText("Score: "+ mScore);
                ///////////////
            }
            else if (respuesta[i] == -1){
                nocontestadas++;


            }
            else {
                incorrectas++;


            }
        }


        //TODO: Permitir traduccion de este texto

        String mensaje = String.format(Locale.getDefault(),
                "Correctas: %d\nIncorrectas %d\nNo contestadas: %d\nPuntaje Final: %d",correctas, incorrectas, nocontestadas,puntaje_);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.results);
        builder.setMessage(mensaje);
        builder.setCancelable(false);
        builder.setPositiveButton(R.string.finish, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });

        builder.setNegativeButton(R.string.start_over, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // borrar respuestas y volver al comienzo

                startOver();
            }
        });
        builder.create().show();

        /*Toast.makeText(MainActivity.this, resultado, Toast.LENGTH_LONG).show();
        finish(); */
    }

    private void showquestion() {
        String p0 = preguntas_todas[pregunta_actual];
        String[] partes = p0.split(";");

        group.clearCheck();
        text_question.setText(partes[0]);



        ////////////////////////////////////////////////////////////////

        //TODO; RAndom
        /*
        int rango = 2, k = 0;
        int arreglo[] = new int[preguntas_todas.length];
        arreglo[k]=(int)(Math.random()*rango);

        for(k=1; k < preguntas_todas.length; k++)
        {
            arreglo[k] = (int)(Math.random()*rango);
            for(int j = 0; j<1; j++)
            {
                if(arreglo[k]==arreglo[j])
                {
                    k--;
                }
            }
        }
        */
        /////////////////////////////////////////////////////////////////

        for (int i=0; i < ids_answers.length; i++)
        {
            RadioButton rb = (RadioButton) findViewById(ids_answers[i]);
            String ans = partes[i+1];
            if (ans.charAt(0) == '*'){
                correct_answer =i;
                ans =ans.substring(1);
                //Toast.makeText(getApplicationContext(),"Correcto",Toast.LENGTH_SHORT).show();
            }
            rb.setText(ans);
            if (respuesta[pregunta_actual] == i)
            {
                rb.setChecked(true);
            }

                //Toast.makeText(getApplicationContext(),"Incorrecto",Toast.LENGTH_SHORT).show();

        }

        if (pregunta_actual == 0){
            btn_prev.setVisibility(View.GONE);

        }
        else{
            btn_prev.setVisibility(View.VISIBLE);

        }
        if(pregunta_actual == preguntas_todas.length-1)
        {
            btn_next.setText(R.string.finish);
        }
        else {
            btn_next.setText(R.string.next);
        }
    }
    public void segundos(View view){
        iniciarCuenta();
    }
    public void iniciarCuenta(){
        int seg = 30;

        CountDownTimer cuenta = new CountDownTimer(seg, 1000) {
            @Override
            public void onTick(long l) {
                long tiempo = l / 1000;
                long segundos = tiempo % 60;
                String segundos_mostrar = String.format("%02d",segundos);
                txt_tiempo.setText(""+segundos_mostrar);
            }

            @Override
            public void onFinish() {
                Toast.makeText(MainActivity.this,"Finalizo",Toast.LENGTH_SHORT).show();
            }
        }.start();
    }
}
